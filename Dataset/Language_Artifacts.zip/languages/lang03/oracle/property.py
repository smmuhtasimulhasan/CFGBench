"""Direct mathematical property checker for lang03.

L = { w c w^R | w in {0,1}* }
"""

ALPHABET = {"0", "1", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("c") != 1:
        return False
    left, right = w.split("c", 1)
    return right == left[::-1]

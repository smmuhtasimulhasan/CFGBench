"""
Direct mathematical property checker for lang41.

L = balanced parentheses strings over {(, )}.
"""

ALPHABET = {"(", ")"}

def accepts_input(w: str) -> bool:
    depth = 0
    for ch in w:
        if ch not in ALPHABET:
            return False
        if ch == "(":
            depth += 1
        else:
            depth -= 1
            if depth < 0:
                return False
    return depth == 0

"""Direct mathematical property checker for lang50.

L = { w in {0,1}* | #0(w) = 2 * #1(w) }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w.count("0") == 2 * w.count("1")

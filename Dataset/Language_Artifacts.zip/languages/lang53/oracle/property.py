"""Direct mathematical property checker for lang53.

L = { a^n b^m | m <= n <= 2m }, including epsilon.
"""

import re

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a*b*", w) is None:
        return False
    n = len(w) - len(w.lstrip("a"))
    m = len(w) - n
    return m <= n <= 2 * m

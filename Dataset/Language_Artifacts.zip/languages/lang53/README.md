# lang53 CFG-Lark Artifact

## Language

- ID: `lang53`
- Class: CFL
- Category: Union Languages
- Alphabet: `{ a, b }`
- Definition: `L = { a^n b^m | m ≤ n ≤ 2m } Equivalent view: Each b requires either 1 or 2 a’s (so total a’s is between m and 2m). Also, if m=0 then n must be 0, so ε is included.`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

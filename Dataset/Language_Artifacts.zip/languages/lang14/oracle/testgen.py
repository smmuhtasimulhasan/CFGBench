"""
Candidate generator for lang14.

This generates candidate strings only. Official suite labels are copied from the
existing frozen benchmark suites, not relabeled here.
"""

from itertools import product

try:
    from . import oracle
except Exception:
    import oracle

ALPHABET = ['a', 'b', 'c']

def generate_candidates(max_len: int = 8):
    seen = set()
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

def labeled_candidates(max_len: int = 8):
    for w in generate_candidates(max_len=max_len):
        yield {"w": w, "label": oracle.accepts_input(w)}

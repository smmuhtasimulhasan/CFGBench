"""
Direct mathematical property checker for lang14.

L = { a^i b^j c^k | i,j,k in N, i > j }, with N including 0.
"""

import re

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a*b*c*", w) is None:
        return False
    return w.count("a") > w.count("b")

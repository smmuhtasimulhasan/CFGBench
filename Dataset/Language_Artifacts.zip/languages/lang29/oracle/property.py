"""
Direct mathematical property checker for lang29.

C = { w in {0,1}* | w = reverse(w) }.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w == w[::-1]

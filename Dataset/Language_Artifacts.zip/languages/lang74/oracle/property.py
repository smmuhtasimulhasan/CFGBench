"""
Direct mathematical property checker for lang74.

L = { a^i c^j b^i | i, j >= 0 }
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    a_count = i
    while i < len(w) and w[i] == "c":
        i += 1
    b_start = i
    while i < len(w) and w[i] == "b":
        i += 1
    b_count = i - b_start
    return i == len(w) and a_count == b_count

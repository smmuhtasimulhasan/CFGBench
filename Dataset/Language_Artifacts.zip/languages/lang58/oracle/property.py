"""
Direct mathematical property checker for lang58.

L = { x c^n : x in {a,b}*, and (#a(x)=n OR #b(x)=n) }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] in {"a", "b"}:
        i += 1
    if any(ch != "c" for ch in w[i:]):
        return False
    x = w[:i]
    n = len(w) - i
    return x.count("a") == n or x.count("b") == n

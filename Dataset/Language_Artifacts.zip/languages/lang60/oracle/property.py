"""
Direct mathematical property checker for lang60.

L = { a^m b^n c^p d^q : m,n,p,q >= 0 and m+n=p+q }.
"""

ALPHABET = {"a", "b", "c", "d"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    k = j
    while k < len(w) and w[k] == "c":
        k += 1
    l = k
    while l < len(w) and w[l] == "d":
        l += 1
    if l != len(w):
        return False
    m = i
    n = j - i
    p = k - j
    q = l - k
    return m + n == p + q

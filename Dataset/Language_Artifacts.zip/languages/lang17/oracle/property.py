"""
Direct mathematical property checker for lang17.

L = { a^n b^m | n <= m <= 2n }, with n,m in N and N including 0.
"""

import re

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a*b*", w) is None:
        return False
    n = w.count("a")
    m = w.count("b")
    return n <= m <= 2 * n

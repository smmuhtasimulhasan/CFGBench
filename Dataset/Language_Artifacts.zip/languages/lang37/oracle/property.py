"""
Direct mathematical property checker for lang37.

L = { a^n b^m | m > n, m,n > 0 }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    if j != len(w):
        return False
    n = i
    m = j - i
    return n > 0 and m > 0 and m > n

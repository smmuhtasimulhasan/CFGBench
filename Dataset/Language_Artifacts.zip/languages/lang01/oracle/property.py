"""Direct mathematical property checker for lang01.

L = { 0^n 1^m 2^m 3^n | n >= 1, m >= 1 }
"""

ALPHABET = {"0", "1", "2", "3"}

def _consume(w: str, i: int, ch: str):
    count = 0
    while i < len(w) and w[i] == ch:
        count += 1
        i += 1
    return count, i

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    n0, i = _consume(w, i, "0")
    n1, i = _consume(w, i, "1")
    n2, i = _consume(w, i, "2")
    n3, i = _consume(w, i, "3")
    return i == len(w) and n0 >= 1 and n1 >= 1 and n2 == n1 and n3 == n0

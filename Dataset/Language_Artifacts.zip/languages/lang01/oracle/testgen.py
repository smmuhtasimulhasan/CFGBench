"""Candidate generator for lang01.

This generates candidate strings only. Official suite labels come from the frozen benchmark suites.
"""

from itertools import product

ALPHABET = ['0', '1', '2', '3']

def generate_candidates(max_len: int = 8):
    yield ""
    for length in range(1, max_len + 1):
        for tup in product(ALPHABET, repeat=length):
            yield "".join(tup)

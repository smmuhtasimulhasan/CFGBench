"""
Direct mathematical property checker for lang72.

L = { w^R w' : w in {a,b}* }, where w' swaps a and b.
"""

ALPHABET = {"a", "b"}
COMP = {"a": "b", "b": "a"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if len(w) % 2 != 0:
        return False
    half = len(w) // 2
    left, right = w[:half], w[half:]
    return right == "".join(COMP[ch] for ch in left[::-1])

"""
Direct mathematical property checker for lang30.

D = { a^i b^j c^k | i,j,k >= 0 and (i = j or j = k) }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    k = j
    while k < len(w) and w[k] == "c":
        k += 1
    if k != len(w):
        return False
    count_a = i
    count_b = j - i
    count_c = k - j
    return count_a == count_b or count_b == count_c

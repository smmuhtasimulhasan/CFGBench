"""
Direct mathematical property checker for lang26.

L = { x=y | x in {1,2}*, y in {5}*, and |x|_1 + 2|x|_2 = 5|y|_5 }.
"""

ALPHABET = {"1", "2", "5", "="}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("=") != 1:
        return False
    left, right = w.split("=", 1)
    if any(ch not in {"1", "2"} for ch in left):
        return False
    if any(ch != "5" for ch in right):
        return False
    return left.count("1") + 2 * left.count("2") == 5 * len(right)

"""Direct mathematical property checker for lang48.

L = { a^m b^n | m, n > 0 and m != n }
"""

import re

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a+b+", w) is None:
        return False
    m = len(w) - len(w.lstrip("a"))
    n = len(w) - m
    return m > 0 and n > 0 and m != n

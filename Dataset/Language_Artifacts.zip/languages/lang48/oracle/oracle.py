"""Oracle wrapper for lang48.

Calls the direct mathematical checker and the independent Lark reference checker.
Raises RuntimeError if the two routes disagree.
"""

from pathlib import Path
import importlib.util

try:
    from . import property as property_oracle
except Exception:
    _property_path = Path(__file__).resolve().parent / "property.py"
    _property_spec = importlib.util.spec_from_file_location("property_oracle_lang48", _property_path)
    property_oracle = importlib.util.module_from_spec(_property_spec)
    assert _property_spec.loader is not None
    _property_spec.loader.exec_module(property_oracle)

_REFERENCE_ORACLE = None

def _load_reference_oracle():
    global _REFERENCE_ORACLE
    if _REFERENCE_ORACLE is None:
        ref_path = Path(__file__).resolve().parents[1] / "reference" / "reference.py"
        spec = importlib.util.spec_from_file_location("reference_oracle_lang48", ref_path)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        _REFERENCE_ORACLE = module
    return _REFERENCE_ORACLE

def accepts_input(w: str) -> bool:
    direct = property_oracle.accepts_input(w)
    ref = _load_reference_oracle().accepts_input(w)
    if direct != ref:
        raise RuntimeError(f"Oracle disagreement on {w!r}: property={direct}, lark_reference={ref}")
    return direct

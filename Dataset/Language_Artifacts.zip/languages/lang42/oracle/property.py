"""
Direct mathematical property checker for lang42.

L = { 0^n 1^n | n >= 0 }.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "0":
        i += 1
    j = i
    while j < len(w) and w[j] == "1":
        j += 1
    return j == len(w) and i == (j - i)

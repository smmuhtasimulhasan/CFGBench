"""
Direct mathematical property checker for lang28.

B = { w in {0,1}* | w = reverse(w) and |w| is odd }.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return len(w) % 2 == 1 and w == w[::-1]

"""
Candidate generator for lang90.

This emits candidate strings only. Official suite labels remain the frozen
benchmark labels copied into tests/suite_*.jsonl.
"""

from itertools import product

try:
    from . import oracle
except Exception:
    import oracle

ALPHABET = ['0', '1']

def generate_candidates(max_len: int = 8):
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            yield "".join(tup)

def generate_labeled_candidates(max_len: int = 8):
    for w in generate_candidates(max_len=max_len):
        yield {"w": w, "label": oracle.accepts_input(w)}

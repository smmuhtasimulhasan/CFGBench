"""Direct mathematical property checker for lang90.

L = { w in {0,1}* | #1(w) = 2 * #0(w) }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w.count("1") == 2 * w.count("0")

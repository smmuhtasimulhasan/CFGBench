"""Direct mathematical property checker for lang07.

L = { a^n b^n c^m | n >= 1, m >= 1 }
"""

ALPHABET = {"a", "b", "c"}

def _consume(w: str, i: int, ch: str):
    count = 0
    while i < len(w) and w[i] == ch:
        count += 1
        i += 1
    return count, i

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    na, i = _consume(w, i, "a")
    nb, i = _consume(w, i, "b")
    nc, i = _consume(w, i, "c")
    return i == len(w) and na >= 1 and nb == na and nc >= 1

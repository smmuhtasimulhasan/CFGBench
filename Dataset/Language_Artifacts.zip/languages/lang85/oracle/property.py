"""
Direct mathematical property checker for lang85.

L = { 0^n 1^(2n) | n >= 0 }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "0":
        i += 1
    zeros = i
    while i < len(w) and w[i] == "1":
        i += 1
    ones = len(w) - zeros
    return i == len(w) and ones == 2 * zeros

"""
Independent reference checker for lang85 using Lark and reference/reference.lark.
"""

from pathlib import Path
from lark import Lark

PARSER_MODE = 'lalr'
_PARSER = None

def _parser():
    global _PARSER
    if _PARSER is None:
        grammar_path = Path(__file__).resolve().parents[1] / "reference" / "reference.lark"
        kwargs = {"parser": PARSER_MODE, "start": "start"}
        if PARSER_MODE == "earley":
            kwargs.update({"lexer": "dynamic", "ambiguity": "resolve"})
        _PARSER = Lark(grammar_path.read_text(encoding="utf-8"), **kwargs)
    return _PARSER

def accepts_input(w: str) -> bool:
    try:
        _parser().parse(w)
        return True
    except Exception:
        return False

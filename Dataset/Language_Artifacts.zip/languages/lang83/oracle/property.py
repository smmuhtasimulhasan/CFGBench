"""
Direct mathematical property checker for lang83.

L = { w in {a,b}* | #a(w) = 2 * #b(w) }
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w.count("a") == 2 * w.count("b")

"""Direct mathematical property checker for lang92.

L = { w in {0,1}* | w starts and ends with the same symbol }, with epsilon rejected.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return len(w) > 0 and w[0] == w[-1]

# lang09 CFG-Lark Artifact

## Language

- ID: `lang09`
- Class: CFL
- Category: Count Constraints
- Alphabet: `{a, b, c, d}`
- Definition: `L = { a^m b^n c^p d^q | m+n = p+q, and m,n,p,q >= 1 }`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

"""Direct mathematical property checker for lang09.

L = { a^m b^n c^p d^q | m+n = p+q, and m,n,p,q >= 1 }
"""

ALPHABET = {"a", "b", "c", "d"}

def _consume(w: str, i: int, ch: str):
    count = 0
    while i < len(w) and w[i] == ch:
        count += 1
        i += 1
    return count, i

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    na, i = _consume(w, i, "a")
    nb, i = _consume(w, i, "b")
    nc, i = _consume(w, i, "c")
    nd, i = _consume(w, i, "d")
    return i == len(w) and min(na, nb, nc, nd) >= 1 and na + nb == nc + nd

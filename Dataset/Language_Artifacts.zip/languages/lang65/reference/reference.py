"""
Independent reference checker for lang65 using Lark and reference/reference.lark.
"""

from pathlib import Path
from lark import Lark

PARSER_KIND = 'earley'
LEXER_KIND = 'basic'
_PARSER = None

def _parser():
    global _PARSER
    if _PARSER is None:
        grammar_path = Path(__file__).resolve().parents[1] / "reference" / "reference.lark"
        kwargs = {
            "parser": PARSER_KIND,
            "lexer": LEXER_KIND,
            "start": "start",
        }
        if PARSER_KIND == "earley":
            kwargs["ambiguity"] = "resolve"
        _PARSER = Lark(grammar_path.read_text(encoding="utf-8"), **kwargs)
    return _PARSER

def accepts_input(w: str) -> bool:
    try:
        _parser().parse(w)
        return True
    except Exception:
        return False

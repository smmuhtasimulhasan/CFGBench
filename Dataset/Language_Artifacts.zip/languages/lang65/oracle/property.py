"""
Direct mathematical property checker for lang65.

L = { a^n b^+ a^m : n >= 0 and exists k >= 0 such that m = 2k+n }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    n = i
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    if j == i:
        return False
    k = j
    while k < len(w) and w[k] == "a":
        k += 1
    if k != len(w):
        return False
    m = k - j
    return m >= n and (m - n) % 2 == 0

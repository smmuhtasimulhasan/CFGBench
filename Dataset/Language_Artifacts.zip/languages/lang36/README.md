# lang36 CFG-Lark Artifact

## Language

- ID: `lang36`
- Class: CFL
- Category: Balanced Brackets
- Alphabet: `{ [, ] }`
- Definition: `J = { w ∈ Σ* | w is a properly balanced bracket string }.`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

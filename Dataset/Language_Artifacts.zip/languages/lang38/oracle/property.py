"""
Direct mathematical property checker for lang38.

L = { a^n b^(n+m) c^m | n,m > 0 }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    k = j
    while k < len(w) and w[k] == "c":
        k += 1
    if k != len(w):
        return False
    a_count = i
    b_count = j - i
    c_count = k - j
    return a_count > 0 and c_count > 0 and b_count == a_count + c_count

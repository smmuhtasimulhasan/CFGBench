"""
Direct mathematical property checker for lang84.

L = { 1^n 0^n | n > 0 }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "1":
        i += 1
    ones = i
    while i < len(w) and w[i] == "0":
        i += 1
    zeros = len(w) - ones
    return i == len(w) and ones > 0 and ones == zeros

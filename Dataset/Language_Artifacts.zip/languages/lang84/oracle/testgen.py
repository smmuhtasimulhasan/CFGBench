"""
Candidate generator for lang84.

This module generates candidate strings only. Official suite labels come from the
existing frozen benchmark suite_01.json, suite_02.json, and suite_03.json files.
"""

from itertools import product

ALPHABET = ['0', '1']

def generate_candidates(max_len: int = 8):
    seen = set()
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

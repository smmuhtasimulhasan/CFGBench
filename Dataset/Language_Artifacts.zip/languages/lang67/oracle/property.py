"""
Direct mathematical property checker for lang67.

L = { 1 0^n 1^n | n > 0 } UNION { 11 0^n 1^(2n) | n > 0 }.
"""

ALPHABET = {"0", "1"}

def _branch_a(w: str) -> bool:
    if not w.startswith("1"):
        return False
    s = w[1:]
    zeros = 0
    while zeros < len(s) and s[zeros] == "0":
        zeros += 1
    ones = len(s) - zeros
    return zeros > 0 and s[zeros:] == "1" * ones and ones == zeros

def _branch_b(w: str) -> bool:
    if not w.startswith("11"):
        return False
    s = w[2:]
    zeros = 0
    while zeros < len(s) and s[zeros] == "0":
        zeros += 1
    ones = len(s) - zeros
    return zeros > 0 and s[zeros:] == "1" * ones and ones == 2 * zeros

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return _branch_a(w) or _branch_b(w)

"""
Direct mathematical property checker for lang25.

B = { bin(i) $ reverse(bin(i+1)) | i >= 0 }, with canonical binary notation:
- bin(0) = "0"
- bin(i) for i > 0 has no leading zeroes.
"""

ALPHABET = {"0", "1", "$"}

def _canonical_binary(s: str) -> bool:
    if s == "":
        return False
    if any(ch not in {"0", "1"} for ch in s):
        return False
    return s == "0" or not s.startswith("0")

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("$") != 1:
        return False
    left, right = w.split("$", 1)
    if not _canonical_binary(left) or any(ch not in {"0", "1"} for ch in right):
        return False
    return right == bin(int(left, 2) + 1)[2:][::-1]

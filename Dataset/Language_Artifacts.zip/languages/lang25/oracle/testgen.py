"""
Candidate generator for lang25.

This generates candidate strings only. Official suite labels are copied from the
existing frozen benchmark suites and are not relabeled by this file.
"""

from itertools import product

ALPHABET = ['0', '1', '$']

def generate_candidates(max_len: int = 8):
    seen = set()
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

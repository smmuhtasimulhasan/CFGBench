"""
Direct mathematical property checker for lang12.

L = { a^n b^m a^n | m,n in N }, with N including 0.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    length = len(w)
    for n in range(length // 2 + 1):
        if w[:n] == "a" * n and w[length - n:] == "a" * n:
            middle = w[n:length - n]
            if all(ch == "b" for ch in middle):
                return True
    return False

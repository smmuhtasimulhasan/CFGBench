"""Direct mathematical property checker for lang04.

L = { w w^R | w in {0,1}* }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return len(w) % 2 == 0 and w == w[::-1]

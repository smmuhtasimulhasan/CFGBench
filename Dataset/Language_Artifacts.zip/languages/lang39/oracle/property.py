"""
Direct mathematical property checker for lang39.

L = { a^n b^(2n) | n > 0 }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    if j != len(w):
        return False
    return i > 0 and (j - i) == 2 * i

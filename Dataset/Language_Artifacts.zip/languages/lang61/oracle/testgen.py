"""
Candidate generator for lang61.

This generates candidate strings only. Official benchmark labels are copied from the
frozen benchmark suites, not produced by this file.
"""

from itertools import product

ALPHABET = ['#', '0', '1']

def generate_candidates(max_len: int = 8):
    seen = set()
    examples = ['1#0', '10#1', '101#001', '1000#111', '0#', '01#0']
    for w in examples:
        if w not in seen:
            seen.add(w)
            yield w
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

if __name__ == "__main__":
    for candidate in generate_candidates():
        print(candidate)

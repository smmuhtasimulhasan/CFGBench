"""
Direct mathematical property checker for lang61.

L = { b_i # (b_{i-1})^R : i >= 1, b_i is binary with no leading zeros }.
"""

ALPHABET = {"0", "1", "#"}

def _binary_no_leading_zero(n: int) -> str:
    return "0" if n == 0 else bin(n)[2:]

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("#") != 1:
        return False
    left, right = w.split("#", 1)
    if not left:
        return False
    if len(left) > 1 and left[0] == "0":
        return False
    i = int(left, 2)
    if i < 1:
        return False
    return right == _binary_no_leading_zero(i - 1)[::-1]

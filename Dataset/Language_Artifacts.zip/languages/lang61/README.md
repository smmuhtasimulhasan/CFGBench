# lang61 CFG-Lark Artifact

## Language

- ID: `lang61`
- Class: CFL
- Category: Palindrome/Reversal
- Alphabet: `{0, 1, #}`
- Definition: `L = { b_i # (b_{i-1})^R : i >= 1, b_i and b_{i-1} are canonical binary representations without leading zeros, and b_0 = 0 }`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

"""
Direct mathematical property checker for lang86.

L = { 1^n 0^n | n > 0 } union { 0^n 1^(2n) | n >= 0 }
"""

ALPHABET = {"0", "1"}

def _ones_zeros(w: str) -> bool:
    i = 0
    while i < len(w) and w[i] == "1":
        i += 1
    ones = i
    while i < len(w) and w[i] == "0":
        i += 1
    zeros = len(w) - ones
    return i == len(w) and ones > 0 and ones == zeros

def _zeros_twones(w: str) -> bool:
    i = 0
    while i < len(w) and w[i] == "0":
        i += 1
    zeros = i
    while i < len(w) and w[i] == "1":
        i += 1
    ones = len(w) - zeros
    return i == len(w) and ones == 2 * zeros

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return _ones_zeros(w) or _zeros_twones(w)

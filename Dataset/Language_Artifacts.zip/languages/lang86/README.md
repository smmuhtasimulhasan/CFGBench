# lang86 CFG-Lark Artifact

## Language

- ID: `lang86`
- Class: CFL
- Category: Union Languages
- Alphabet: `{0, 1}`
- Definition: `L = { 1^n 0^n | n > 0 } ∪ { 0^n 1^(2n) | n ≥ 0 }.`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

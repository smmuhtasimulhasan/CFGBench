"""
Direct mathematical property checker for lang34.

L = { a b^n a c a b^n a | n >= 0 }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if not (w.startswith("a") and w.endswith("a")):
        return False
    middle = w[1:-1]
    n = 0
    while n < len(middle) and middle[n] == "b":
        n += 1
    if middle[n:n+3] != "aca":
        return False
    return middle[n+3:] == "b" * n

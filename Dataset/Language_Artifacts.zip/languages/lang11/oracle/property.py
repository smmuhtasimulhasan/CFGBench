"""
Direct mathematical property checker for lang11.

L = { w in {a,b}* | #a(w) = #b(w) }
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w.count("a") == w.count("b")

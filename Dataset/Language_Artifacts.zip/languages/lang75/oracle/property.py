"""
Direct mathematical property checker for lang75.

L = { w w^R | w in {a,b}+ }
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return len(w) > 0 and len(w) % 2 == 0 and w == w[::-1]

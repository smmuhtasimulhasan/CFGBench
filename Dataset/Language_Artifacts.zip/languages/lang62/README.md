# lang62 CFG-Lark Artifact

## Language

- ID: `lang62`
- Class: CFL
- Category: Palindrome/Reversal
- Alphabet: `{0, 1, #}`
- Definition: `L = { x#y : x,y ∈ {0,1}* and reverse(x) (i.e., x^R) is a substring of y }.`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

"""
Direct mathematical property checker for lang62.

L = { x#y : x,y in {0,1}* and reverse(x) is a substring of y }.
"""

ALPHABET = {"0", "1", "#"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("#") != 1:
        return False
    x, y = w.split("#", 1)
    return x[::-1] in y

"""
Direct mathematical property checker for lang70.

L = { a^m b^n | m >= n }
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    seen_b = False
    a_count = 0
    b_count = 0
    for ch in w:
        if ch == "a":
            if seen_b:
                return False
            a_count += 1
        else:
            seen_b = True
            b_count += 1
    return a_count >= b_count

"""
Direct mathematical property checker for lang13.

L = { a^n b^m c^m | m,n in N }, with N including 0.
"""

import re

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a*b*c*", w) is None:
        return False
    return w.count("b") == w.count("c")

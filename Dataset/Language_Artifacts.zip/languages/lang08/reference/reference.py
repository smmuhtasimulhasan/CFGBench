"""Independent reference checker for lang08 using Lark and reference/reference.lark."""

from pathlib import Path
from lark import Lark

_PARSER = None
_PARSER_NAME = 'lalr'
_LEXER_NAME = 'basic'

def _parser():
    global _PARSER
    if _PARSER is None:
        grammar_path = Path(__file__).resolve().parents[1] / "reference" / "reference.lark"
        kwargs = {"parser": _PARSER_NAME, "lexer": _LEXER_NAME, "start": "start"}
        if _PARSER_NAME == "earley":
            kwargs["ambiguity"] = "resolve"
        _PARSER = Lark(grammar_path.read_text(encoding="utf-8"), **kwargs)
    return _PARSER

def accepts_input(w: str) -> bool:
    try:
        _parser().parse(w)
        return True
    except Exception:
        return False

"""Direct mathematical property checker for lang08.

L = { a^n b^n | n >= 1 }
"""

ALPHABET = {"a", "b"}

def _consume(w: str, i: int, ch: str):
    count = 0
    while i < len(w) and w[i] == ch:
        count += 1
        i += 1
    return count, i

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    na, i = _consume(w, i, "a")
    nb, i = _consume(w, i, "b")
    return i == len(w) and na >= 1 and nb == na

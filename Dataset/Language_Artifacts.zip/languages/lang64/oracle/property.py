"""
Direct mathematical property checker for lang64.

L$ = { w$ : w in {a,b}* and #a(w)=#b(w) }.
"""

ALPHABET = {"a", "b", "$"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if not w.endswith("$") or w.count("$") != 1:
        return False
    body = w[:-1]
    return body.count("a") == body.count("b")

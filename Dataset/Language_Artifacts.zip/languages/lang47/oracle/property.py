"""Direct mathematical property checker for lang47.

L = { a^i b^j c^k | i, j, k > 0 and (i = j or i = k) }
"""

import re

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a+b+c+", w) is None:
        return False
    i = len(w) - len(w.lstrip("a"))
    k = len(w) - len(w.rstrip("c"))
    j = len(w) - i - k
    return i > 0 and j > 0 and k > 0 and (i == j or i == k)

"""
Direct mathematical property checker for lang22.

L = { x reverse(x) | x in {a,b}* }, equivalently even-length palindromes.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return len(w) % 2 == 0 and w == w[::-1]

"""
Direct mathematical property checker for lang68.

L = { w in {0,1}* : |w| >= 1, first(w)=last(w), and #0(w)=#1(w) }.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if len(w) < 1:
        return False
    return w[0] == w[-1] and w.count("0") == w.count("1")

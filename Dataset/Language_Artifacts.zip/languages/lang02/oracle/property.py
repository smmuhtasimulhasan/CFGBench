"""Direct mathematical property checker for lang02.

L = { 0^n 1^m | n >= 1, m >= 1, m > n + 2 }
"""

ALPHABET = {"0", "1"}

def _consume(w: str, i: int, ch: str):
    count = 0
    while i < len(w) and w[i] == ch:
        count += 1
        i += 1
    return count, i

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    n0, i = _consume(w, i, "0")
    n1, i = _consume(w, i, "1")
    return i == len(w) and n0 >= 1 and n1 >= 1 and n1 > n0 + 2

"""
Direct mathematical property checker for lang19.

L = { w1 c w2 c ... wk c x | wi,x in {a,b}*, k >= 1,
      and x = mir(wj) for some j }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if "c" not in w:
        return False
    parts = w.split("c")
    x = parts[-1]
    prior_blocks = parts[:-1]
    return any(x == block[::-1] for block in prior_blocks)

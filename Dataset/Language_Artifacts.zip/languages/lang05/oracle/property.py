"""Direct mathematical property checker for lang05.

L = { w w^R | w in {0,1}* } UNION { w c w^R | w in {0,1}* }
"""

ALPHABET = {"0", "1", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    c_count = w.count("c")
    if c_count == 0:
        return len(w) % 2 == 0 and w == w[::-1]
    if c_count == 1:
        left, right = w.split("c", 1)
        return right == left[::-1]
    return False

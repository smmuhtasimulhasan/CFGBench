"""
Candidate generator for lang49.

This module generates candidate strings only. It does not relabel official suites;
the official suite labels are copied from frozen benchmark suite_01/02/03 JSON.
"""

from itertools import product

ALPHABET = ['0', '1']

def generate_candidates(max_len: int = 12):
    seen = set()
    yield ""
    seen.add("")
    for length in range(1, max_len + 1):
        for tup in product(ALPHABET, repeat=length):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

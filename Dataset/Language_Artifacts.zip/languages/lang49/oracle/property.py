"""Direct mathematical property checker for lang49.

L = { 0^(2n) 1^n | n > 0 }
"""

import re

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"0+1+", w) is None:
        return False
    zeros = len(w) - len(w.lstrip("0"))
    ones = len(w) - zeros
    return ones > 0 and zeros == 2 * ones

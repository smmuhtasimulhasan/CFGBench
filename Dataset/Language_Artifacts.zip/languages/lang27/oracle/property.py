"""
Direct mathematical property checker for lang27.

A = { w in {0,1}* | w contains at least three 1s }.
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w.count("1") >= 3

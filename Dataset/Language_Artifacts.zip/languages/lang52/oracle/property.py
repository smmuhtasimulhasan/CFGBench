"""Direct mathematical property checker for lang52.

L = { a^(3k+2) b^(2k+1) | k >= 0 }
"""

import re

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a+b+", w) is None:
        return False
    a_count = len(w) - len(w.lstrip("a"))
    b_count = len(w) - a_count
    if b_count <= 0 or b_count % 2 != 1:
        return False
    k = (b_count - 1) // 2
    return a_count == 3 * k + 2

# lang52 CFG-Lark Artifact

## Language

- ID: `lang52`
- Class: CFL
- Category: Count Constraints
- Alphabet: `{ a, b }`
- Definition: `L = { a^i b^j | 2i = 3j + 1 } Equivalent form: Let j = 2k+1 (must be odd). Then i = 3k+2. So L = { a^(3k+2) b^(2k+1) | k >= 0 }.`

## Contents

This folder preserves the language ID in its path and contains the formal language specification, trusted reference grammar route, executable oracle route, conformance report, frozen test suites, and suite audit report.

## Files

- `language.txt`
- `class.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

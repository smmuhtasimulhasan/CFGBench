"""
Direct mathematical property checker for lang43.

L = { v # v^R | v in {a,b,#}* }.
"""

ALPHABET = {"a", "b", "#"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if len(w) % 2 != 1:
        return False
    mid = len(w) // 2
    if w[mid] != "#":
        return False
    return w[mid + 1:] == w[:mid][::-1]

"""
Candidate generator for lang43.

This generates candidate strings only. Final official suite labels are copied from
the frozen benchmark suites, not relabeled here.
"""

from itertools import product

ALPHABET = ["a", "b", "#"]

def generate_candidates(max_len: int = 8):
    seen = set()
    for n in range(max_len + 1):
        for tup in product(ALPHABET, repeat=n):
            w = "".join(tup)
            if w not in seen:
                seen.add(w)
                yield w

"""
Direct mathematical property checker for lang40.

L = { w c w^R | w in {a,b}* }.
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if w.count("c") != 1:
        return False
    left, right = w.split("c", 1)
    return right == left[::-1]

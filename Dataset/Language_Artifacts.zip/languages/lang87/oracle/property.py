"""
Direct mathematical property checker for lang87.

L = (0+1)* - { ww | w in {0,1}* }
"""

ALPHABET = {"0", "1"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if len(w) % 2 != 0:
        return True
    half = len(w) // 2
    return w[:half] != w[half:]

"""Direct mathematical property checker for lang51.

BalDelim = properly balanced strings over (), [], {}.
"""

ALPHABET = {"(", ")", "[", "]", "{", "}"}
PAIRS = {")": "(", "]": "[", "}": "{"}
OPENS = set(PAIRS.values())

def accepts_input(w: str) -> bool:
    stack = []
    for ch in w:
        if ch not in ALPHABET:
            return False
        if ch in OPENS:
            stack.append(ch)
        else:
            if not stack or stack[-1] != PAIRS[ch]:
                return False
            stack.pop()
    return not stack

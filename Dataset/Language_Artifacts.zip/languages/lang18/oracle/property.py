"""
Direct mathematical property checker for lang18.

PAL = { w in {a,b}* | mir(w) = w }
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    return w == w[::-1]

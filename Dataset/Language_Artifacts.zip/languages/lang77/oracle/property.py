"""
Direct mathematical property checker for lang77.

L = { a^m b^n c^(m+n) | m, n >= 1 }
"""

ALPHABET = {"a", "b", "c"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    a_count = i
    b_start = i
    while i < len(w) and w[i] == "b":
        i += 1
    b_count = i - b_start
    c_start = i
    while i < len(w) and w[i] == "c":
        i += 1
    c_count = i - c_start
    return i == len(w) and a_count >= 1 and b_count >= 1 and c_count == a_count + b_count

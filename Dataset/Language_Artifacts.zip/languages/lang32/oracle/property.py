"""
Direct mathematical property checker for lang32.

F = { a^(2n) b^(3n) | n >= 0 }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    if any(ch != "b" for ch in w[i:]):
        return False
    return i % 2 == 0 and len(w[i:]) == 3 * (i // 2)

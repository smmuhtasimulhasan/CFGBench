"""Direct mathematical property checker for lang57.

L = { a^n b^m a^n | n,m >= 0 and m is even }.
"""

import re

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    if re.fullmatch(r"a*b*a*", w) is None:
        return False
    if "b" not in w:
        return len(w) % 2 == 0
    first_b = w.find("b")
    last_b = w.rfind("b")
    left_a = first_b
    right_a = len(w) - last_b - 1
    middle_b = last_b - first_b + 1
    return left_a == right_a and middle_b % 2 == 0

"""
Independent reference checker for lang57 using Lark and reference/reference.lark.
"""

import re
from pathlib import Path
from lark import Lark

LANGUAGE_ID = 'lang57'
PARSER_MODE = 'lalr'
STARTS = ['start']

_PARSER = None
_PARSERS = None

def _grammar_text() -> str:
    grammar_path = Path(__file__).resolve().parents[1] / "reference" / "reference.lark"
    return grammar_path.read_text(encoding="utf-8")

def _parser():
    global _PARSER
    if _PARSER is None:
        grammar = _grammar_text()
        if PARSER_MODE == "lalr":
            start = STARTS if len(STARTS) > 1 else STARTS[0]
            _PARSER = Lark(grammar, parser="lalr", lexer="basic", start=start)
        elif PARSER_MODE == "earley":
            _PARSER = Lark(grammar, parser="earley", lexer="dynamic", start=STARTS[0], ambiguity="resolve")
        else:
            raise RuntimeError(f"Unsupported parser mode for {LANGUAGE_ID}: {PARSER_MODE}")
    return _PARSER

def _mixed_parsers():
    global _PARSERS
    if _PARSERS is None:
        grammar = _grammar_text()
        _PARSERS = {
            "less_ij": Lark(grammar, parser="lalr", lexer="basic", start="less_ij"),
            "less_jk": Lark(grammar, parser="lalr", lexer="basic", start="less_jk"),
            "greater_ij": Lark(grammar, parser="earley", lexer="dynamic", start="greater_ij", ambiguity="resolve"),
            "greater_jk": Lark(grammar, parser="earley", lexer="dynamic", start="greater_jk", ambiguity="resolve"),
        }
        # Also ensure the declared start rule builds as a complete Lark CFG.
        Lark(grammar, parser="earley", lexer="dynamic", start="start", ambiguity="resolve")
    return _PARSERS

def _parse_with_start(parser, w: str, start: str = None) -> bool:
    try:
        if start is None:
            parser.parse(w)
        else:
            parser.parse(w, start=start)
        return True
    except Exception:
        return False

def accepts_input(w: str) -> bool:
    return _parse_with_start(_parser(), w)


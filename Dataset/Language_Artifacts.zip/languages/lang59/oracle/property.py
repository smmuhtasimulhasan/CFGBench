"""
Direct mathematical property checker for lang59.

L = { a^n b^m : m >= n, and (m-n) is even }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "a":
        i += 1
    j = i
    while j < len(w) and w[j] == "b":
        j += 1
    if j != len(w):
        return False
    n = i
    m = len(w) - i
    return m >= n and (m - n) % 2 == 0

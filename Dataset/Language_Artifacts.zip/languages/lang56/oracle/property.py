"""Direct mathematical property checker for lang56.

L = { w in {a,b}* | every prefix of w has at least as many a's as b's }.
"""

ALPHABET = {"a", "b"}

def accepts_input(w: str) -> bool:
    balance = 0
    for ch in w:
        if ch == "a":
            balance += 1
        elif ch == "b":
            balance -= 1
        else:
            return False
        if balance < 0:
            return False
    return True

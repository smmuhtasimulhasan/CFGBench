"""
Direct mathematical property checker for lang45.

L = { 0^i 1^j 2^k | i,j,k >= 0 and i = k }.
"""

ALPHABET = {"0", "1", "2"}

def accepts_input(w: str) -> bool:
    if any(ch not in ALPHABET for ch in w):
        return False
    i = 0
    while i < len(w) and w[i] == "0":
        i += 1
    j = i
    while j < len(w) and w[j] == "1":
        j += 1
    k = j
    while k < len(w) and w[k] == "2":
        k += 1
    if k != len(w):
        return False
    return i == (k - j)

# CFGBench EMNLP Language Artifacts — Submission ZIP

This archive contains 286 context-free-language artifacts under `languages/langXX/`.

The language folder IDs are intentionally preserved from the source artifact. They are not renumbered, so the sequence is non-contiguous; skipped numbers correspond to source entries that are not included in this filtered 286-language submission.

Each language folder contains:

- `README.md`
- `class.txt`
- `language.txt`
- `reference/reference.lark`
- `reference/reference.py`
- `reference/reference_lark_status.json`
- `oracle/property.py`
- `oracle/oracle.py`
- `oracle/testgen.py`
- `oracle/conformance_report.json`
- `tests/suite_1.jsonl`
- `tests/suite_2.jsonl`
- `tests/suite_3.jsonl`
- `tests/audit_report.json`

Per the submission requirements, no `metadata.json` and no `question.txt` files are included.

Each `language.txt` contains only four fields:

1. `ID`
2. `Category`
3. `Alphabet`
4. `Definition`

Each language has three frozen test suites. Each suite has 300 cases: 150 positive and 150 negative. Therefore each language has 900 total tests, and the archive has 257,400 total test cases.

The executable validation routes are:

- `oracle/property.py`: direct mathematical membership checker.
- `reference/reference.py`: independent Lark reference grammar checker.
- `oracle/oracle.py`: wrapper that compares the direct property route with the Lark reference route.

Audit and conformance reports are included inside each language folder.
